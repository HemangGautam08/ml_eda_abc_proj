#!/bin/zsh
# =============================================================================
# 07_install_ml_into_abc.sh  — CORRECTED
#
# KEY FIX: After injection, verifies the override appears AFTER
# If_ObjPerformMapping (not before), catching any regex mis-fire.
# Everything else is unchanged from the previous version.
# =============================================================================

cd "$(dirname "$0")"

export ABC_DIR="${ABC_DIR:-/Users/hemanggautam/Desktop/eda_proj/abc}"
IF_DIR="$ABC_DIR/src/map/if"
PATCH_DIR="abc_patch"

echo "Installing ML files into ABC: $ABC_DIR"
echo "Source patch dir: $(pwd)/$PATCH_DIR"

# ── Check required files ──────────────────────────────────────────────────────
for f in "$PATCH_DIR/ifML.c" "$PATCH_DIR/model_weights.h"; do
  if [[ ! -f "$f" ]]; then
    echo "ERROR: $f not found."
    if [[ "$f" == *"model_weights.h"* ]]; then
      echo "  Run:  python3 06_export_weights_to_c.py"
    else
      echo "  ifML.c should be in abc_patch/ — check your project folder."
    fi
    exit 1
  fi
done

# Verify model_weights.h has ML_INPUT_DIM 14 (not old 12)
EXPECTED_DIM=14
ACTUAL_DIM=$(grep "define ML_INPUT_DIM" "$PATCH_DIR/model_weights.h" | awk '{print $3}')
if [[ "$ACTUAL_DIM" != "$EXPECTED_DIM" ]]; then
  echo "ERROR: model_weights.h has ML_INPUT_DIM=$ACTUAL_DIM but expected $EXPECTED_DIM."
  echo "  Re-run: python3 06_export_weights_to_c.py"
  exit 1
fi
echo "model_weights.h: ML_INPUT_DIM=$ACTUAL_DIM  ✓"

# ── Copy ML source files ──────────────────────────────────────────────────────
cp "$PATCH_DIR/ifML.c"          "$IF_DIR/ifML.c"
cp "$PATCH_DIR/model_weights.h" "$IF_DIR/model_weights.h"
echo "Copied ifML.c and model_weights.h to $IF_DIR  ✓"

# ── Add ifML.c to module.make ─────────────────────────────────────────────────
MODULE_MAKE="$IF_DIR/module.make"
if ! grep -q "ifML.c" "$MODULE_MAKE"; then
  echo "SRC += src/map/if/ifML.c" >> "$MODULE_MAKE"
  echo "Added ifML.c to module.make"
else
  echo "module.make already references ifML.c"
fi

# ── Patch if.h: forward declarations ─────────────────────────────────────────
python3 << 'PYEOF'
import os, sys

abc_dir = os.environ.get('ABC_DIR', '/Users/hemanggautam/Desktop/eda_proj/abc')
path    = f"{abc_dir}/src/map/if/if.h"

with open(path) as f:
    src = f.read()

if 'If_ObjOverrideCutWithML' in src:
    print("if.h: If_ObjOverrideCutWithML already declared — skipping")
    sys.exit(0)

decl = (
    '\n/* Per-node ML cut override — called after If_ObjPerformMapping */\n'
    '#ifdef USE_ML\n'
    'extern void If_ObjOverrideCutWithML( If_Man_t * p, If_Obj_t * pObj );\n'
    'extern void If_ManMLScoreAllCuts( If_Man_t * p );\n'
    '#endif /* USE_ML */\n'
)

lines = src.rstrip().split('\n')
last_endif = next((i for i in range(len(lines)-1, -1, -1)
                   if lines[i].strip().startswith('#endif')), -1)
if last_endif >= 0:
    lines.insert(last_endif, decl)
    src = '\n'.join(lines) + '\n'
else:
    src += decl

with open(path, 'w') as f:
    f.write(src)
print("if.h: If_ObjOverrideCutWithML declaration added")
PYEOF
[[ $? -ne 0 ]] && exit 1

# ── Patch ifMap.c: inject If_ObjOverrideCutWithML AFTER per-node mapping ──────
python3 << 'PYEOF'
import re, os, sys

abc_dir = os.environ.get('ABC_DIR', '/Users/hemanggautam/Desktop/eda_proj/abc')
path    = f"{abc_dir}/src/map/if/ifMap.c"

with open(path) as f:
    src = f.read()

if 'If_ObjOverrideCutWithML' in src:
    print("ifMap.c: If_ObjOverrideCutWithML already injected — skipping")
    sys.exit(0)

# Remove old incorrect pre-pass if present
if 'If_ManMLScoreAllCuts' in src:
    old = re.compile(
        r'#ifdef USE_ML\s*\n\s*/\*.*?\*/\s*\n\s*If_ManMLScoreAllCuts\s*\(\s*p\s*\)\s*;\s*\n#endif\s*/\*\s*USE_ML\s*\*/\s*\n',
        re.DOTALL
    )
    src, n = old.subn('', src)
    if n:
        print(f"ifMap.c: removed {n} old If_ManMLScoreAllCuts pre-pass block(s)")

ml_call = (
    '#ifdef USE_ML\n'
    '        If_ObjOverrideCutWithML( p, pObj );\n'
    '#endif /* USE_ML */\n'
)

injected = False
for pat in [
    r'(If_ObjPerformMapping\s*\(\s*p\s*,\s*pObj\s*,\s*Mode\s*\)\s*;)',
    r'(If_ObjPerformMappingAnd\s*\([^)]+\)\s*;)',
    r'(If_ObjPerformMapping\s*\(\s*p\s*,\s*pObj\s*\)\s*;)',
]:
    src_new, n = re.subn(pat, r'\1\n        ' + ml_call, src, count=1)
    if n:
        src      = src_new
        injected = True
        print(f"ifMap.c: If_ObjOverrideCutWithML injected after node mapping  ✓")
        break

if not injected:
    print("WARNING: Could not find If_ObjPerformMapping — add manually:")
    print("  After the per-node mapping call, insert:")
    print("    #ifdef USE_ML")
    print("    If_ObjOverrideCutWithML( p, pObj );")
    print("    #endif")
    sys.exit(1)

with open(path, 'w') as f:
    f.write(src)
print("ifMap.c patched.")
PYEOF
[[ $? -ne 0 ]] && exit 1

# ── Verify injection is AFTER the mapping call, not before ───────────────────
python3 << 'PYEOF'
import os, sys, re
abc_dir = os.environ.get('ABC_DIR', '/Users/hemanggautam/Desktop/eda_proj/abc')
path    = f"{abc_dir}/src/map/if/ifMap.c"
with open(path) as f:
    src = f.read()
# Find relative position of PerformMapping and ObjOverrideCutWithML
pm_pos  = [m.start() for m in re.finditer(r'If_ObjPerformMapping', src)]
ml_pos  = [m.start() for m in re.finditer(r'If_ObjOverrideCutWithML', src)]
if not pm_pos or not ml_pos:
    print("WARNING: could not verify injection order")
    sys.exit(0)
# The first ML call should come AFTER the first PerformMapping call
if ml_pos[0] > pm_pos[0]:
    print("Injection order verified: override is AFTER mapping call  ✓")
else:
    print("ERROR: If_ObjOverrideCutWithML appears BEFORE If_ObjPerformMapping!")
    print("  Injection failed. Check ifMap.c manually.")
    sys.exit(1)
PYEOF
[[ $? -ne 0 ]] && exit 1

# ── Build abc_ml (USE_ML) ─────────────────────────────────────────────────────
cd "$ABC_DIR" || exit 1
NCPU=$(sysctl -n hw.ncpu)

echo "\n── Building abc_ml (USE_ML enabled) ────────────────────────────────────"
make clean > /dev/null 2>&1
make -j"$NCPU" OPTFLAGS="-O2 -DUSE_ML" ABC_USE_NO_READLINE=1 2>&1 | tail -10
if [[ $? -ne 0 ]]; then
  echo "ERROR: abc_ml build failed."
  echo "Tip:  cd $ABC_DIR && make -j1 OPTFLAGS='-O2 -DUSE_ML' ABC_USE_NO_READLINE=1"
  exit 1
fi
cp abc abc_ml
echo "Created: $ABC_DIR/abc_ml  ✓"

# ── Rebuild clean baseline ────────────────────────────────────────────────────
echo "\n── Building abc (clean baseline) ───────────────────────────────────────"
make clean > /dev/null 2>&1
make -j"$NCPU" OPTFLAGS="-O2" ABC_USE_NO_READLINE=1 2>&1 | tail -4
if [[ $? -ne 0 ]]; then
  echo "ERROR: baseline abc build failed."
  exit 1
fi
echo "Created: $ABC_DIR/abc  ✓"

echo ""
for bin in abc abc_ml; do
  if [[ -f "$ABC_DIR/$bin" ]]; then
    sz=$(du -sh "$ABC_DIR/$bin" | cut -f1)
    echo "  ✓ $bin  ($sz)"
  else
    echo "  ✗ $bin NOT FOUND"
  fi
done

echo "\nDone. Next: python3 08_compare_qor.py"