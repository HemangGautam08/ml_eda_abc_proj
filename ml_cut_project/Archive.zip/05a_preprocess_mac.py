#!/usr/bin/env python3
"""
05a_preprocess_mac.py  — CORRECTED
=====================================
Run on your Mac BEFORE going to Colab.

KEY FIXES vs previous version:
  [FIX-1] Infinity filter: rows where required_time or slack is ABC_INFINITY
          (from round-0 dumps) are dropped BEFORE the scaler is fitted.
          Without this, scaler_mean[4] and scaler_mean[5] become ~7e19 which
          makes ALL timing features constant at inference (≈ -1.666).

  [FIX-2] Label changed from adj_score to MFFC-based label.
          adj_score = f(area_flow, delay) which are ABC's OWN heuristics.
          Training to rank by adj_score just teaches the model to copy ABC.
          New label uses mffc_size (MFFC node count) as primary signal:
            - Larger MFFC = more nodes are "free" under this cut (no extra
              area cost) because they have no other fanout.
            - ABC does NOT directly optimise MFFC size; it optimises area_flow
              which is a DAG-sharing estimate, not an MFFC count.
          Combined label: mffc_size / n_leaves  (area efficiency of cut)
          adjusted by a timing penalty when the cut is on the critical path.

  [FIX-3] mffc_size added to FEATURE_NAMES so the model can also use it
          as an input feature (it sees both the raw signal and the label).

Run from: ~/Desktop/eda_proj/ml_cut_project/
Requires: data/*_cuts.csv   (from 04_generate_training_data.sh)
Produces: ml/train_data.npz
          ml/scaler.pkl
          ml/features.txt
"""

import os, sys, glob, time, pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

# ── Config ────────────────────────────────────────────────────────────────────
DATA_DIR = "data"
ML_DIR   = "ml"
SEED     = 42

# FIX-3: mffc_size added as feature
FEATURE_NAMES = [
    "n_leaves", "cut_delay", "area_flow", "node_level",
    "required_time", "slack", "node_fanout",
    "slack_ratio", "delay_ratio", "fanout_adj_area",
    "area_per_leaf", "is_critical",
    "mffc_size",          # NEW: MFFC node count — exogenous to ABC heuristics
    "mffc_per_leaf",      # NEW: mffc_size / n_leaves — area efficiency ratio
]
N_FEATURES = len(FEATURE_NAMES)   # 14

MAX_PAIRS_PER_NODE = 20
INF_THRESH         = 1e7    # values above this are ABC_INFINITY

os.makedirs(ML_DIR, exist_ok=True)
np.random.seed(SEED)

# ── 1. Load CSVs ──────────────────────────────────────────────────────────────
csv_files = sorted(glob.glob(os.path.join(DATA_DIR, "*_cuts.csv")))
if not csv_files:
    sys.exit(f"ERROR: no *_cuts.csv in {DATA_DIR}/. Run 04_generate_training_data.sh first.")

print(f"Loading {len(csv_files)} CSV file(s)...")
frames = []
for f in csv_files:
    circuit_name = os.path.basename(f).replace("_cuts.csv", "")
    df_c = pd.read_csv(f)
    df_c["circuit"] = circuit_name
    frames.append(df_c)

df = pd.concat(frames, ignore_index=True)
print(f"  Total rows (raw) : {len(df):,}")
print(f"  Columns          : {list(df.columns)}")

# ── Guard: required columns ───────────────────────────────────────────────────
for col in ["node_id", "n_leaves", "cut_delay", "area_flow",
            "node_level", "required_time", "slack", "node_fanout",
            "mffc_size", "is_best"]:
    if col not in df.columns:
        if col == "mffc_size":
            print("WARNING: mffc_size missing — re-run 03_apply_abc_patch.sh (updated version)")
            print("  Falling back to floor(area_flow + 0.5) as mffc_size proxy.")
            df["mffc_size"] = (df["area_flow"] + 0.5).astype(int).clip(lower=1)
        elif col == "node_fanout":
            print("WARNING: node_fanout missing — falling back to 1.")
            df["node_fanout"] = 1
        else:
            sys.exit(f"ERROR: missing column '{col}'.")

df["node_fanout"] = df["node_fanout"].clip(lower=1)
df["mffc_size"]   = df["mffc_size"].clip(lower=1, upper=1000)

# ── FIX-1: Drop infinity-timing rows ─────────────────────────────────────────
n_before = len(df)
bad_mask = (df["required_time"].abs() > INF_THRESH) | (df["slack"].abs() > INF_THRESH)
df = df[~bad_mask].copy()
df = df.reset_index(drop=True)
n_dropped = n_before - len(df)
if n_dropped > 0:
    print(f"\n[FIX-1] Dropped {n_dropped:,} rows ({100*n_dropped/n_before:.1f}%) "
          f"with ABC_INFINITY timing (round-0 dump artefacts).")
    print(f"  Remaining rows: {len(df):,}")
else:
    print(f"\n[FIX-1] ✓ No infinity-timing rows found — round guard is working.")

if len(df) == 0:
    sys.exit("ERROR: All rows were dropped by infinity filter. "
             "Check that abc_dump was built with the updated 03_apply_abc_patch.sh.")

# ── 2. Feature engineering ────────────────────────────────────────────────────
print("\nEngineering features...")
eps     = 1e-6
req_abs = df["required_time"].abs() + eps

df["slack_ratio"]     = df["slack"]      / req_abs
df["delay_ratio"]     = df["cut_delay"]  / req_abs
df["fanout_adj_area"] = df["area_flow"]  / (np.sqrt(df["node_fanout"]) + eps)
df["area_per_leaf"]   = df["area_flow"]  / (df["n_leaves"] + eps)
df["is_critical"]     = (df["slack"] <= 0).astype(float)
# FIX-3: derived MFFC feature
df["mffc_per_leaf"]   = df["mffc_size"]  / (df["n_leaves"] + eps)

# ── FIX-2: MFFC-based label ───────────────────────────────────────────────────
#
# Why MFFC?
#   area_flow is ABC's internal "expected area" for a cut.  It already
#   accounts for DAG sharing globally.  Training to minimise area_flow-based
#   scores just replicates what ABC's own cut comparator already does.
#
#   mffc_size counts nodes that are EXCLUSIVELY reachable through this cut's
#   root — i.e. nodes that will be "absorbed for free" if this cut is chosen.
#   A higher mffc_size means more logic is contained within this cut at no
#   extra cost, which is good for area AND potentially for timing (shorter
#   critical paths through the MFFC).
#
# Label construction:
#   mffc_score = mffc_size / n_leaves   (larger = better area efficiency)
#
#   timing_penalty:  when slack <= 0 (critical path), we also want small
#                    cut_delay.  Multiply by 1/(1 + delay_penalty) so
#                    critical-path cuts with large delay are penalised.
#                    On non-critical nodes, timing_penalty = 0.
#
#   combined_score = mffc_score * timing_factor
#   BETTER cut = HIGHER combined_score  (opposite sign convention to adj_score)
#
print("[FIX-2] Computing MFFC-based label (exogenous to ABC heuristics)...")

# mffc_score: area efficiency — higher = better
mffc_score = df["mffc_size"] / (df["n_leaves"] + eps)

# timing factor: penalise high-delay cuts on critical path
#   alpha controls how much timing matters: 0 = pure area, 1 = pure timing
#   We use 0.4 for critical nodes, 0.1 for slack nodes (timing still matters
#   a little to avoid creating new critical paths)
alpha = np.where(df["slack"] <= 0, 0.4, 0.1)
delay_norm   = df["cut_delay"] / (df["cut_delay"].max() + eps)  # 0..1
timing_factor = 1.0 / (1.0 + alpha * delay_norm)

df["mffc_combined"] = mffc_score * timing_factor

# Normalise per-node to [0, 1] quality score (1 = best cut for this node)
def node_quality_mffc(g):
    mn, mx = g.min(), g.max()
    if mx > mn:
        return (g - mn) / (mx - mn)   # higher mffc_combined = higher quality
    return pd.Series(1.0, index=g.index)

df["quality"] = df.groupby(["circuit", "node_id"])["mffc_combined"].transform(node_quality_mffc)

# best cut per node = highest mffc_combined score
node_max = df.groupby(["circuit", "node_id"])["mffc_combined"].transform("max")
df["is_mffc_best"] = (df["mffc_combined"] - node_max).abs() < 1e-9

# How often does ABC's own choice agree with the MFFC-best cut?
# If this is near 100%, the label still correlates with ABC and gains are limited.
# If it's 50-70%, the label disagrees with ABC enough to teach something new.
abc_total  = (df["is_best"] == 1).sum()
mffc_agree = (df["is_best"].astype(bool) & df["is_mffc_best"]).sum()
print(f"  ABC picks MFFC-optimal cut: {mffc_agree / abc_total:.1%}  "
      f"(lower = more room for improvement)")
print(f"  (comparison: if this were ~100%, label would still be circular)")

# ── 3. Pairwise training data (RankNet) ───────────────────────────────────────
print("\nGenerating pairwise training data (ranked by mffc_combined)...")
t0 = time.time()

X_full   = df[FEATURE_NAMES].values.astype(np.float32)
circuits = df["circuit"].values

pair_better, pair_worse = [], []

for (circuit, node_id), grp in df.groupby(["circuit", "node_id"]):
    if len(grp) < 2:
        continue
    # Sort DESCENDING by mffc_combined — index 0 = best cut
    grp_sorted = grp.sort_values("mffc_combined", ascending=False)
    pos_idxs   = grp_sorted.index.tolist()
    n          = len(pos_idxs)

    best_pos    = pos_idxs[0]
    pairs_added = 0
    for worse_pos in pos_idxs[1:]:
        pair_better.append(best_pos)
        pair_worse.append(worse_pos)
        pairs_added += 1
        if pairs_added >= MAX_PAIRS_PER_NODE:
            break

    # Extra signal: 2nd-best vs worst
    if n >= 4 and pairs_added < MAX_PAIRS_PER_NODE:
        pair_better.append(pos_idxs[1])
        pair_worse.append(pos_idxs[-1])

pair_better = np.array(pair_better, dtype=np.int64)
pair_worse  = np.array(pair_worse,  dtype=np.int64)
print(f"  Pairs: {len(pair_better):,}  (took {time.time() - t0:.1f}s)")

# ── 4. Fit StandardScaler ─────────────────────────────────────────────────────
# FIX-1 ensures no infinity rows reach here, so the scaler will fit correctly.
print("\nFitting StandardScaler...")
scaler   = StandardScaler()
X_scaled = scaler.fit_transform(X_full).astype(np.float32)
print(f"  mean range : [{scaler.mean_.min():.3f}, {scaler.mean_.max():.3f}]")
print(f"  std  range : [{scaler.scale_.min():.3f}, {scaler.scale_.max():.3f}]")

# Sanity check — required_time mean should now be in hundreds, not e19
req_idx = FEATURE_NAMES.index("required_time")
slk_idx = FEATURE_NAMES.index("slack")
print(f"\n  Sanity check (should be finite, reasonable values):")
print(f"    required_time  mean={scaler.mean_[req_idx]:.2f}  std={scaler.scale_[req_idx]:.2f}")
print(f"    slack          mean={scaler.mean_[slk_idx]:.2f}  std={scaler.scale_[slk_idx]:.2f}")
if scaler.mean_[req_idx] > 1e7:
    print("  WARNING: required_time mean is still huge — infinity filter may not have worked!")
    sys.exit(1)
else:
    print("  ✓ Scaler looks healthy")

# ── 5. Circuit-level train/val split ─────────────────────────────────────────
unique_circuits = np.unique(circuits)
n_circuits      = len(unique_circuits)

if n_circuits == 1:
    print("WARNING: only 1 circuit — using it for both train and val.")
    val_circuits   = set(unique_circuits)
    train_circuits = set(unique_circuits)
else:
    rng = np.random.default_rng(SEED)
    shuffled       = rng.permutation(unique_circuits)
    n_val          = max(1, int(n_circuits * 0.2))
    val_circuits   = set(shuffled[:n_val])
    train_circuits = set(shuffled[n_val:])

print(f"\nTrain circuits ({len(train_circuits)}): {sorted(train_circuits)}")
print(f"Val   circuits ({len(val_circuits)}):   {sorted(val_circuits)}")

# ── 6. Save scaler ────────────────────────────────────────────────────────────
scaler_pkl = os.path.join(ML_DIR, "scaler.pkl")
with open(scaler_pkl, "wb") as f:
    pickle.dump({"scaler": scaler, "feature_names": FEATURE_NAMES}, f)
print(f"\nSaved: {scaler_pkl}")

with open(os.path.join(ML_DIR, "features.txt"), "w") as f:
    for i, name in enumerate(FEATURE_NAMES):
        f.write(f"{i}\t{name}\n")
print(f"Saved: ml/features.txt")

# ── 7. Export train_data.npz ──────────────────────────────────────────────────
npz_path = os.path.join(ML_DIR, "train_data.npz")
print(f"\nSaving {npz_path} ...")

np.savez_compressed(
    npz_path,
    X_scaled        = X_scaled,
    pair_better     = pair_better,
    pair_worse      = pair_worse,
    circuits        = np.array(circuits),
    unique_circuits = unique_circuits,
    quality         = df["quality"].values.astype(np.float32),
    adj_score_best  = df["is_mffc_best"].values.astype(np.bool_),
    is_best         = df["is_best"].values.astype(np.int8),
    scaler_mean     = scaler.mean_.astype(np.float32),
    scaler_scale    = scaler.scale_.astype(np.float32),
    feature_names   = np.array(FEATURE_NAMES),
)

size_kb = os.path.getsize(npz_path) / 1024
print(f"Saved: {npz_path}  ({size_kb:.0f} KB)")

# ── Summary ───────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("Preprocessing complete.")
print(f"  Rows      : {len(df):,}")
print(f"  Features  : {N_FEATURES}  (was 12, now 14 with mffc columns)")
print(f"  Pairs     : {len(pair_better):,}")
print(f"  Circuits  : {n_circuits}  (train={len(train_circuits)}, val={len(val_circuits)})")
print(f"  Label     : mffc_combined (MFFC-based, exogenous to ABC heuristics)")
print("=" * 60)
print("""
Next steps
----------
1. Upload  ml/train_data.npz  to Google Drive
   (My Drive/ml_cut_project/train_data.npz)

2. Open 05b_train_colab.ipynb in Google Colab
   (Runtime → Change runtime type → T4 GPU)

3. Run all cells — model trains on MFFC-based labels.

4. Download  ml/cut_model_mlp.pt  from Drive → place at ml/cut_model_mlp.pt

5. Run:  python3 06_export_weights_to_c.py
""")